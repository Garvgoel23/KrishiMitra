const Footer=()=>{
    return (
        <div className="w-screen p-6 flex items-center justify-center text-center bg-black">
            <h1 className={'text-sm text-white'}> 2025 : KrishiMitra</h1>
        </div>
    )
}
export default Footer;