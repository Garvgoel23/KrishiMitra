import Navbar from "./Navbar.jsx";
import {useState} from "react";

const PestDetection=()=>{

    const [selectedFile, setSelectedFile] = useState(null);

    const handleChange = (event) => {
        const file = event.target.files[0];
        if(file){
            console.log(file)
            const fileURL = URL.createObjectURL(file);
            console.log(fileURL);
            setSelectedFile(fileURL);
        }
    }

    return (
        <div className={'overflow-hidden relative h-screen w-full flex flex-col items-center justify-center bg-[url("https://extension.psu.edu/media/catalog/product/c/8/c821d56ca2f2fd3276c65fc06e9476a3.jpeg?quality=80&bg-color=255,255,255&fit=bounds&height=&width=&canvas=:")] bg-cover bg-center' }>
            <Navbar/>
            <div className={'h-[70%] w-[53%] bg-gradient-to-br from-zinc-800/50 via-zinc-900/50 to-zinc-950/50 backdrop-blur-sm rounded-3xl border border-gray-500 p-10 flex flex-col items-center justify-between text-white'}>
                <h1 className={'text-3xl font-medium mb-3'}>Pest Detection</h1>
                <div className={'flex items-center w-full h-[85%]'}>
                    <div className={'h-full w-[50%] p-2.5 flex flex-col items-center justify-between'}>
                        <div className={' border border-gray-500 bg-zinc-700/30 rounded-2xl w-[80%] h-[80%] flex flex-col items-center justify-center'}>
                            <h1>Enter Image</h1>
                            {!selectedFile ? (<input
                                type="file"
                                accept="image/*"
                                onChange={handleChange}
                                className="bg-zinc-400 rounded-lg w-20 h-10 text-xs text-center flex items-center justify-center px-1 pt-2 pb-2 overflow-hidden whitespace-nowrap text-ellipsis"
                            />) :
                                (
                                    <img
                                        className={''}
                                        src={selectedFile} alt=""/>
                                )}
                        </div>
                        <button
                            // onClick={handleSubmit}
                            className={'px-8 py-2 border-2 border-white rounded-full font-medium my-2'}>
                            Detect Pest
                        </button>
                    </div>
                    <div className={'h-full w-[50%] border-l-2 border-gray-500 flex flex-col items-center justify-center text-center'}>

                    </div>
                </div>
            </div>
            {/*<input*/}
            {/*    type="file"*/}
            {/*    accept={"image/*"}*/}
            {/*    onChange={handleChange}*/}
            {/*    className={'bg-gray-400 rounded-lg'}*/}
            {/*/>*/}
            {/*{selectedFile && (*/}
            {/*    <img*/}
            {/*        className={'w-48 h-48'}*/}
            {/*        src={selectedFile} alt=""/>*/}
            {/*)}*/}

        </div>
    )
}
export default PestDetection